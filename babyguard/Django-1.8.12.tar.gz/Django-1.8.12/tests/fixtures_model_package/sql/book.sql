INSERT INTO fixtures_model_package_book (name) VALUES ('My Book');
