import nonexistent.module  # NOQA
